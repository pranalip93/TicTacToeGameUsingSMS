package com.example.tttgamebroadcastreceiver;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class TTTGame extends AppCompatActivity implements View.OnClickListener {
    private Button[][] buttons = new Button[3][3];
    private boolean player1Turn=true;
    TextView phoneNumberSender = null;
    private int roundCount;
    String buttonID;
    TextView winnerAnnounce,playerName=null;
    SmsManager smsManager = SmsManager.getDefault();
    Button b00,b01,b02,b10,b11,b12,b20,b21,b22=null;
    public static String setPhoneNumber;
    String phNumber;
    int i,j;
    ImageView imageView=null;
    Bitmap bitmap;
    String settingsName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_board);
        Intent intent = getIntent();
        settingsName = intent.getStringExtra("Name");
        bitmap = (Bitmap) intent.getParcelableExtra("Bitmap");
        imageView=findViewById(R.id.player1Icon);
        imageView.setImageBitmap(bitmap);
        playerName=findViewById(R.id.player1NameText);
        playerName.setText(settingsName);
        phoneNumberSender=findViewById(R.id.phoneNumber);
        phoneNumberSender.setText(setPhoneNumber);
        winnerAnnounce=findViewById(R.id.winnerMessage);
        for (i = 0; i < 3; i++) {
            for (j = 0; j < 3; j++) {
                buttonID = "button_" + i + j;
                int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
                buttons[i][j] = findViewById(resID);
                buttons[i][j].setOnClickListener(this);
            }
        }

        TTTGameReceiver smsReceiver = new TTTGameReceiver(this);

        if(!isSmsPermissionGranted()){
            requestReadAndSendSmsPermission();
        }

    }
    @Override
    public void onClick(View v) {
        if (!((Button) v).getText().toString().equals("")) {
            return;
        }
        else if (player1Turn) {
            ((Button) v).setText("X");
            Button id = (Button) v;
            player1Turn = !player1Turn;
            String idButton = String.valueOf(id.getId());
            phNumber = phoneNumberSender.getText().toString();
            smsManager.sendTextMessage(phNumber, null, idButton, null, null);
            ((Button) v).setEnabled(false);
        }
        else {
            ((Button) v).setText("O");
            Button id = (Button) v;
            player1Turn = !player1Turn;
            String idButton = String.valueOf(id.getId());
            phNumber = phoneNumberSender.getText().toString();
            smsManager.sendTextMessage(phNumber, null, idButton, null, null);
            ((Button) v).setEnabled(false);
        }
        roundCount++;
        if (checkForWin()) {
            if (player1Turn) {
                player1Wins();
            } else {
                player2Wins();
            }
        } else if (roundCount == 9) {
            draw();
        }
    }
    private boolean checkForWin() {
        String[][] field = new String[3][3];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                field[i][j] = buttons[i][j].getText().toString();
            }
        }
        for (int i = 0; i < 3; i++) {
            if (field[i][0].equals(field[i][1])
                    && field[i][0].equals(field[i][2])
                    && !field[i][0].equals("")) {
                return true;
            }
        }
        for (int i = 0; i < 3; i++) {
            if (field[0][i].equals(field[1][i])
                    && field[0][i].equals(field[2][i])
                    && !field[0][i].equals("")) {
                return true;
            }
        }
        if (field[0][0].equals(field[1][1])
                && field[0][0].equals(field[2][2])
                && !field[0][0].equals("")) {
            return true;
        }
        if (field[0][2].equals(field[1][1])
                && field[0][2].equals(field[2][0])
                && !field[0][2].equals("")) {
            return true;
        }
        return false;
    }
    private void player1Wins() {

        winnerAnnounce.setText("Player 2 Wins!");
    }
    private void player2Wins() {

        winnerAnnounce.setText("Player 1 Wins!");

    }
    private void draw() {
        winnerAnnounce.setText("Game Draw!");

    }
    public void setText(String phone)
    {
        phoneNumberSender=findViewById(R.id.phoneNumber);
        phoneNumberSender.setText(phone);
    }
    public void tttUpdateDisplay(String phone, String newMessage) {
        phoneNumberSender.setText(phone);
        if(player1Turn==true) {
            int id = Integer.parseInt(newMessage);
            Button b = findViewById(id);
            b.setText("X");
            player1Turn = !player1Turn;
            b.setEnabled(false);
        }
        else
        {
            int id = Integer.parseInt(newMessage);
            Button b = findViewById(id);
            b.setText("O");
            player1Turn = !player1Turn;
            b.setEnabled(false);
        }
        roundCount++;
        if (checkForWin()) {
            if (player1Turn) {
                player1Wins();
            } else {
                player2Wins();
            }
        } else if (roundCount == 9) {
            draw();
        }
    }

    public boolean isSmsPermissionGranted() {
        return ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED;
    }

    /**
     * Request runtime SMS permission
     */
    private void requestReadAndSendSmsPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_SMS)) {

        }
        ActivityCompat.requestPermissions(this,
                new String[]{
                        Manifest.permission.READ_SMS,
                        Manifest.permission.SEND_SMS,
                        Manifest.permission.RECEIVE_SMS,
                        Manifest.permission.READ_PHONE_STATE
                },
                1);
    }


}

