package com.example.tttgamebroadcastreceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import androidx.annotation.RequiresApi;

public class SMSReceiver extends BroadcastReceiver {
    MainActivity mainActivity = null;

    public SMSReceiver(MainActivity _main) {
        mainActivity = _main;
        mainActivity.registerReceiver(this, new IntentFilter("android.provider.Telephony.SMS_RECEIVED"));
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public void onReceive(Context context, Intent intent) {
        SmsMessage[] smsMessages = Telephony.Sms.Intents.getMessagesFromIntent(intent);
        if (smsMessages != null) {
            String phone = smsMessages[0].getDisplayOriginatingAddress().toString();
            String message = smsMessages[0].getDisplayMessageBody();
            if(message.equals("1")||message.equals("2")||message.equals("3"))
            {
                mainActivity.updateDisplay(phone, message);
            }

        }
    }

}

