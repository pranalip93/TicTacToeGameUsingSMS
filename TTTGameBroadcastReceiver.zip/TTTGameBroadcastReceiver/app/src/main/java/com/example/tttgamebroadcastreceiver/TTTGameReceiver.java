package com.example.tttgamebroadcastreceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import android.util.Log;

import androidx.annotation.RequiresApi;

public class TTTGameReceiver extends BroadcastReceiver {
    TTTGame tttGame=null;

    public TTTGameReceiver(TTTGame _game)
    {
        tttGame=_game;
        tttGame.registerReceiver(this,new IntentFilter("android.provider.Telephony.SMS_RECEIVED"));
    }
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public void onReceive(Context context, Intent intent) {
        SmsMessage[] smsMessages = Telephony.Sms.Intents.getMessagesFromIntent(intent);
        if (smsMessages != null) {
            String phone = smsMessages[0].getDisplayOriginatingAddress().toString();
            String message = smsMessages[0].getDisplayMessageBody();
            tttGame.tttUpdateDisplay(phone,message);
            tttGame.setText(phone);
        }
    }

}


