package com.example.tttgamebroadcastreceiver;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button sendButton = null;
    String settingsName;
    EditText phoneNumber= null;
    SmsManager smsManager = SmsManager.getDefault();
    Button reject,accept=null;
    ImageButton settingButton=null;
    TextView joinRequest,playerName=null;
    TextView phoneNumberReceiver=null;
    TTTGame tttGame;
    TextView rejectNumber,messageAssign=null;
    ImageView imageView=null;
    Bitmap bitmap;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sendButton = findViewById(R.id.sendButton);
        //phoneNumberTextView = findViewById(R.id.phoneNumberTextView);
        phoneNumber = findViewById(R.id.phoneNumberText);
        settingButton=findViewById(R.id.settingsButton);
        settingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Settings.class);
                startActivity(intent);
            }
        });
        Intent intent = getIntent();
        settingsName = intent.getStringExtra("Name");
       bitmap = (Bitmap) intent.getParcelableExtra("Bitmap");
        imageView=findViewById(R.id.imageIcon);
        imageView.setImageBitmap(bitmap);
        playerName=findViewById(R.id.playerName);
        playerName.setText(settingsName);
        messageAssign = findViewById(R.id.messageText);
        phoneNumberReceiver=findViewById(R.id.phoneNumber);
        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumberAssign = phoneNumber.getText().toString();
                String message ="1";
                String messagePlayerOne="Invitation sent..";
                messageAssign.setText(messagePlayerOne);
                smsManager.sendTextMessage(phoneNumberAssign, null, message, null, null);

            }
        });
        SMSReceiver smsReceiver = new SMSReceiver(this);
        if(!isSmsPermissionGranted()){
            requestReadAndSendSmsPermission();
        }

    }


    public void updateDisplay(final String phone, String messageNew){
        //messageNew="Request Sent";
        if(messageNew.equalsIgnoreCase("1"))
        {
            setContentView(R.layout.accept_reject);
            phoneNumberReceiver=findViewById(R.id.acceptPhone);
            joinRequest=findViewById(R.id.joinRequest);
            phoneNumberReceiver.setText(phone);
            imageView=findViewById(R.id.playerIcon);
            imageView.setImageBitmap(bitmap);
            playerName=findViewById(R.id.playerNameText);
            playerName.setText(settingsName);
            joinRequest.setText("wants to play would you like to join? You will be Player 2!");
            accept=findViewById(R.id.acceptButton);
            accept.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onPause();
                    newGame();
                    String phoneNumberAssign = phoneNumberReceiver.getText().toString();
                    String message="2";
                    tttGame.setPhoneNumber=phoneNumberAssign;
                    smsManager.sendTextMessage(phoneNumberAssign, null, message, null, null);
                }
            });
            reject=findViewById(R.id.rejectButton);
            reject.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String message="3";
                    String phoneNumberAssign = phoneNumberReceiver.getText().toString();
                    smsManager.sendTextMessage(phoneNumberAssign, null, message, null, null);
                }
            });
        }else if(messageNew.equalsIgnoreCase("2"))
        {
            setContentView(R.layout.accept_reject);
            imageView=findViewById(R.id.playerIcon);
            imageView.setImageBitmap(bitmap);
            playerName=findViewById(R.id.playerNameText);
            playerName.setText(settingsName);
            phoneNumberReceiver=findViewById(R.id.acceptPhone);
            joinRequest=findViewById(R.id.joinRequest);
            phoneNumberReceiver.setText(phone);
            joinRequest.setText("Accepts request. You are player 1! ");
            accept=findViewById(R.id.acceptButton);
            accept.setText("Start");
            accept.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    newGame();
                    tttGame.setPhoneNumber=phoneNumberReceiver.getText().toString();
                }
            });
            reject=findViewById(R.id.rejectButton);
            reject.setEnabled(false);
        }
        else if(messageNew.equalsIgnoreCase("3")){
            setContentView(R.layout.sorry_page);
            rejectNumber=findViewById(R.id.sorryText);
            rejectNumber.setText(phone);
        }

    }

    private void newGame() {
        Intent intent = new Intent(getApplicationContext(), TTTGame.class);
        intent.putExtra("Name", settingsName);
        // intent.putExtra("imageId",imageId);
        intent.putExtra("Bitmap", bitmap);
        startActivity(intent);
    }

    /**
     * Check if we have SMS permission
     */
    public boolean isSmsPermissionGranted() {
        return ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED;
    }

    /**
     * Request runtime SMS permission
     */
    private void requestReadAndSendSmsPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_SMS)) {
            // You may display a non-blocking explanation here, read more in the documentation:

            // https://developer.android.com/training/permissions/requesting.html
        }
        ActivityCompat.requestPermissions(this,
                new String[]{
                        Manifest.permission.READ_SMS,
                        Manifest.permission.SEND_SMS,
                        Manifest.permission.RECEIVE_SMS,
                        Manifest.permission.READ_PHONE_STATE
                },
                1);
    }
}