package com.example.tttgamebroadcastreceiver;

import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Settings extends AppCompatActivity {
    Button save=null;
    EditText settingName= null;
    String name;
    Bitmap b;
    ImageView imageIcon1,imageIcon2,imageIcon3,imageIcon4,imageIcon5,imageIcon6=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setting);
        settingName=findViewById(R.id.settingsName);
        save=findViewById(R.id.saveButton);

        imageIcon1 = findViewById(R.id.boy);
        imageIcon2 = findViewById(R.id.april);
        imageIcon3 = findViewById(R.id.bunny);
        imageIcon4 = findViewById(R.id.leonardo);
        imageIcon5 = findViewById(R.id.fish);
        imageIcon6 = findViewById(R.id.panda);
        imageIcon1.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onClick(View v) {
                imageIcon1.setDrawingCacheEnabled(true);
                b=imageIcon1.getDrawingCache();
                animImage(imageIcon1);

            }
        });
        imageIcon2.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onClick(View v) {
                imageIcon2.setDrawingCacheEnabled(true);
                b=imageIcon2.getDrawingCache();
                animImage(imageIcon2);
            }
        });
        imageIcon3.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onClick(View v) {
                imageIcon3.setDrawingCacheEnabled(true);
                b=imageIcon3.getDrawingCache();
                animImage(imageIcon3);
            }
        });
        imageIcon4.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onClick(View v) {
                imageIcon4.setDrawingCacheEnabled(true);
                b=imageIcon4.getDrawingCache();
                animImage(imageIcon4);
            }
        });
        imageIcon5.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onClick(View v) {
                imageIcon5.setDrawingCacheEnabled(true);
                b=imageIcon5.getDrawingCache();
                animImage(imageIcon5);
            }
        });
        imageIcon6.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onClick(View v) {
                imageIcon6.setDrawingCacheEnabled(true);
                b=imageIcon6.getDrawingCache();
                animImage(imageIcon6);
            }
        });
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name=settingName.getText().toString();
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.putExtra("Name", name);
               // intent.putExtra("imageId",imageId);
                intent.putExtra("Bitmap", b);
                startActivity(intent);
            }
        });
    }
    @SuppressLint("WrongConstant")
    public void animImage(ImageView imageIcon)
    {
        ObjectAnimator anim = ObjectAnimator.ofInt(imageIcon, "backgroundColor", Color.WHITE, Color.TRANSPARENT,
                Color.WHITE);
        anim.setDuration(1500);
        anim.setEvaluator(new ArgbEvaluator());
        anim.setRepeatMode(Animation.REVERSE);
        anim.setRepeatCount(Animation.INFINITE);
        anim.start();
    }
}
